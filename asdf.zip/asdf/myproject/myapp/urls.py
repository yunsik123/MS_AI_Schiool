from django.urls import path
from . import views  # views 모듈을 임포트합니다.
from django.urls import path
from .views import classification_page, detail_page, image_upload_page

urlpatterns = [
    path('', views.main_page, name='main_page'),
    path('classification/', views.classification_page, name='classification_page'),
    path('detail/', views.detail_page, name='detail_page'),  # detail 페이지 패턴
    path('image-upload/', views.image_upload_page, name='image_upload_page'),
]