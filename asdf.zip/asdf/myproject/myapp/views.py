import os
import requests
from django.shortcuts import render
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from .utils import classify_image
import json
from django.shortcuts import render
from django.http import HttpResponseNotFound
from django.conf import settings

def main_page(request):
    return render(request, 'myapp/main.html')

def image_upload_page(request):
    if request.method == 'POST' and 'image' in request.FILES:
        image = request.FILES['image']
        fs = FileSystemStorage()
        filename = fs.save(image.name, image)
        uploaded_file_url = fs.url(filename)

        # Custom Vision API 요청
        try:
            image_path = os.path.join(settings.MEDIA_ROOT, filename)
            predictions = classify_image(image_path)

            # 예측 결과
            top_prediction = predictions["predictions"][0]
            predicted_class = top_prediction["tagName"]
            probability = top_prediction["probability"]

            return render(request, 'myapp/classification.html', {
                'uploaded_file_url': uploaded_file_url,
                'predicted_class': predicted_class,
                'probability': probability,
            })

        except requests.RequestException as e:
            # API 요청 실패 시 처리
            return render(request, 'myapp/error.html', {
                'error_message': f"예측 요청 실패: {str(e)}"
            })

    return render(request, 'myapp/image_upload.html')

def classification_page(request):
    return render(request, 'myapp/classification.html')

from django.shortcuts import render
from django.http import HttpResponse, HttpResponseNotFound
import json
import os
from django.conf import settings

def detail_page(request):
    product_name = request.GET.get('product_name')
    uploaded_image_url = request.GET.get('uploaded_image_url')

    # JSON 파일 경로 설정
    json_path = os.path.join(settings.BASE_DIR, 'myapp', 'static', 'products.json')
    
    # JSON 파일 읽기
    try:
        with open(json_path, 'r', encoding='utf-8') as f:
            products = json.load(f)
    except FileNotFoundError:
        return HttpResponseNotFound("JSON 파일을 찾을 수 없습니다.")
    except json.JSONDecodeError:
        return HttpResponse("JSON 파일을 읽는 중 오류가 발생했습니다.", status=500)
    
    # JSON에서 데이터 가져오기
    product = products.get(product_name)
    
    if not product:
        return HttpResponseNotFound("제품 정보를 찾을 수 없습니다.")

    context = {
        'uploaded_image_url': uploaded_image_url,
        'product_name': product['name'],
        'category': product['category'],
        'product_code': product['product_code'],
        'price': product['price'],
        'origin': product['origin'],
        'description': product.get('description', '설명 정보가 없습니다.'),  # description 추가
    }

    return render(request, 'myapp/detail_page.html', context)

